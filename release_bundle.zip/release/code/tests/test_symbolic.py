"""Tests for absorb.symbolic.

Each ``check_*`` is exercised twice: once through its own assertion machinery,
and once through an independent spot check performed here, so that a check that
silently degenerated into a tautology would still be caught.
"""
# covers: eq:perturbations-vorticity, prop:vorticity-obstruction, prop:geodesic-forced, prop:four-form, prop:clock, prop:no-rolling, eq:outlook-reynolds-eos, eq:realizations-lnrate, eq:realizations-alpha
#   Six labels were removed from this line: thm:quasi-positivity,
#   thm:no-sign-flip, prop:recipient-proportional, thm:regular-future,
#   thm:de-sitter, thm:sandwich, thm:sign-table. Nothing in this file
#   tested any of them; the header had drifted from the code and the
#   ledger reported coverage that did not exist, for claims two of which
#   appear in the abstract. They are now covered by test_theorems.py and
#   by test_background.py, which do test them.
#   Machine-readable link from tests to the claims they cover, read by
#   scripts/claim_ledger.py. A claim quoted in the abstract or the
#   conclusions with nothing testing it is what the ledger exists to find.

from __future__ import annotations

import sympy as sp

from absorb import symbolic as sy


# ---------------------------------------------------------------------------
# the six claims
# ---------------------------------------------------------------------------
def test_four_form() -> None:
    assert sy.check_four_form() is True


def test_four_form_equation_of_state() -> None:
    """Independent check: the four-form fluid has w = -1 in FLRW.

    T_munu = -(h^2/2) g_munu means rho = T_00 = h^2/2 and
    p = T_11/g_11 = -h^2/2.
    """
    t = sp.Symbol("t", real=True)
    a = sp.Function("a", positive=True)(t)
    h = sp.Symbol("h", positive=True)
    g = sp.diag(-1, a ** 2, a ** 2, a ** 2)
    T = -h ** 2 / 2 * g
    rho = T[0, 0]                       # u^mu u^nu T_munu with u = (1,0,0,0)
    p = sp.simplify(T[1, 1] / g[1, 1])
    assert sp.simplify(p + rho) == 0


def test_clock_action() -> None:
    assert sy.check_clock_action() is True


def test_clock_action_is_dust_plus_vacuum() -> None:
    """Independent check: on the constraint the clock's energy density is
    lambda + V and its pressure is -V, i.e. dust plus a vacuum term."""
    lam, V = sp.symbols("lamda V", positive=True)
    t = sp.Symbol("t", real=True)
    a = sp.Function("a", positive=True)(t)
    g = sp.diag(-1, a ** 2, a ** 2, a ** 2)
    # comoving clock: T = t, so d_mu T = (1,0,0,0), u_mu = (-1,0,0,0)
    u = sp.Matrix([-1, 0, 0, 0])
    T = sp.Matrix(4, 4, lambda i, j: lam * u[i] * u[j] - V * g[i, j])
    rho = T[0, 0]
    p = sp.simplify(T[1, 1] / g[1, 1])
    assert sp.simplify(rho - (lam + V)) == 0
    assert sp.simplify(p + V) == 0


def test_flrw() -> None:
    assert sy.check_flrw() is True


def test_flrw_matter_solution() -> None:
    """Independent check: a ~ t^(2/3) solves G_00 = rho/Mpl^2 with p = 0."""
    t = sp.Symbol("t", positive=True)
    a = t ** sp.Rational(2, 3)
    H = sp.diff(a, t) / a
    Hdot = sp.diff(H, t)
    rho = 3 * H ** 2                       # Mpl = 1
    p = -(2 * Hdot + 3 * H ** 2)
    assert sp.simplify(p) == 0
    assert sp.simplify(sp.diff(rho, t) + 3 * H * (rho + p)) == 0


def test_jerk_identity() -> None:
    assert sy.check_jerk_identity() is True


def test_jerk_is_one_for_lcdm() -> None:
    """Independent check: a constant p (a cosmological constant plus dust)
    gives j = 1 exactly, which is the null hypothesis the paper tests."""
    t = sp.Symbol("t", positive=True)
    Mpl = sp.Symbol("M_Pl", positive=True)
    # LCDM: rho = rho_m0 a^-3 + Lambda-like constant, so p = -const
    a = sp.Function("a", positive=True)(t)
    H = sp.diff(a, t) / a
    p = sp.Symbol("p_const")
    j = 1 - sp.diff(p, t) / (2 * Mpl ** 2 * H ** 3)
    assert sp.simplify(j - 1) == 0


def test_growth_equation() -> None:
    assert sy.check_growth_equation() is True


def test_growth_reduces_to_standard_case() -> None:
    """With gamma_c = 0 the growth equation is the textbook one."""
    t = sp.Symbol("t", real=True)
    Mpl = sp.Symbol("M_Pl", positive=True)
    delta = sp.Function("delta")(t)
    H = sp.Function("H")(t)
    rho = sp.Function("rho")(t)
    gam = sp.Integer(0)
    eq = (
        sp.diff(delta, t, 2)
        + (2 * H - gam) * sp.diff(delta, t)
        - (rho / (2 * Mpl ** 2) + sp.diff(gam, t) + 2 * H * gam) * delta
    )
    standard = sp.diff(delta, t, 2) + 2 * H * sp.diff(delta, t) - rho * delta / (2 * Mpl ** 2)
    assert sp.simplify(eq - standard) == 0


def test_solvable_family() -> None:
    assert sy.check_solvable_family() is True


def test_solvable_family_limits() -> None:
    """xi -> 0 must switch the conversion off and freeze every density."""
    a, xi, b = sp.symbols("a xi b", positive=True)
    rho_I0, rho_D0, V0, f0 = sp.symbols("rho_I0 rho_D0 V0 f0", real=True)
    rho_I = rho_I0 * a ** (-(3 + xi))
    rho_D = a ** (-3) * (rho_D0 + b * rho_I0 * (1 - a ** (-xi)))
    V = V0 + xi * (1 - b) * rho_I0 * (1 - a ** (-(3 + xi))) / (3 + xi)
    f = 1 - (1 - f0) * a ** (-xi)
    assert sp.simplify(sp.limit(rho_I, xi, 0) - rho_I0 * a ** -3) == 0
    assert sp.simplify(sp.limit(rho_D, xi, 0) - rho_D0 * a ** -3) == 0
    assert sp.simplify(sp.limit(V, xi, 0) - V0) == 0
    assert sp.simplify(sp.limit(f, xi, 0) - f0) == 0


# ---------------------------------------------------------------------------
# aggregate entry point
# ---------------------------------------------------------------------------
def test_run_all() -> None:
    results = sy.run_all()
    assert set(results) == {fn.__name__ for fn in sy.ALL_CHECKS}
    assert all(results.values())


def test_upward_nucleation_rate_rises_with_accumulated_flux():
    """The four-form bridge's reinforcement, derived rather than argued.

    Section 8.5 originally concluded that the upward rate rises because the
    entropy suppression Delta S falls as the vacuum grows. That controls the
    *ratio* Gamma_up / Gamma_down; a downward rate falling faster would have
    carried the upward rate down with it. This checks the completed statement:
    with the thin-wall bounce for the downward channel and detailed balance
    against the de Sitter entropy, both contributions to log Gamma_up scale as
    h^-3 and both push the same way.
    """
    import sympy as sp

    h, q, sigma, Mpl, N = sp.symbols("h q sigma M_pl N", positive=True)

    B_down = 27 * sp.pi**2 * sigma**4 / (2 * (q * h) ** 3)
    S = 24 * sp.pi**2 * Mpl**4 / (h**2 / 2)
    delta_S = sp.series(S - S.subs(h, h + q), q, 0, 2).removeO()

    ln_gamma_up = sp.simplify(-B_down - delta_S)

    # (i) it is -K/h^3 with K > 0
    K = sp.simplify(-ln_gamma_up * h**3)
    assert sp.simplify(sp.diff(K, h)) == 0, "K must not depend on h"
    assert sp.simplify(K.subs({sigma: 1, Mpl: 1, q: 1})) > 0

    # (ii) the rate rises with flux
    d1 = sp.simplify(sp.diff(ln_gamma_up, h))
    assert sp.simplify(d1.subs({sigma: 1, Mpl: 1, q: 1, h: 2})) > 0

    # (iii) relative curvature across a swept range N q is 4 N q / h
    d2 = sp.diff(ln_gamma_up, h, 2)
    curvature = sp.simplify(sp.Abs(d2) * N * q / sp.Abs(d1))
    assert sp.simplify(curvature - 4 * N * q / h) == 0

    # (iv) alpha = 3 (N q / h) Delta S in the entropy-dominated regime
    alpha_entropy = sp.simplify(N * q * sp.diff(-delta_S, h))
    assert sp.simplify(alpha_entropy / delta_S - 3 * N * q / h) == 0


def test_exact_vacuum_fed_without_momentum_transfer_forbids_vorticity():
    """Q_V omega_{mu nu} = 0, checked on explicit tensors.

    The integrability of the transfer is standard; the vorticity corollary is
    what the geometric readings of the outlook keep running into, so the index
    placement is verified rather than quoted. Built from a concrete unit
    timelike u, a spatial acceleration, a spatial symmetric traceless shear and
    a spatial antisymmetric vorticity, all satisfying their constraints.
    """
    import numpy as np

    rng = np.random.default_rng(3)
    eta = np.diag([-1.0, 1.0, 1.0, 1.0])

    v = rng.normal(size=3) * 0.3
    gamma = 1.0 / np.sqrt(1.0 - v @ v)
    u_up = np.array([gamma, *(gamma * v)])
    u_dn = eta @ u_up
    assert abs(u_up @ eta @ u_up + 1.0) < 1e-12

    h = eta + np.outer(u_dn, u_dn)
    h_mixed = np.linalg.inv(eta) @ h

    def spatial(M):
        return h_mixed.T @ M @ h_mixed

    sym = rng.normal(size=(4, 4))
    sigma = spatial((sym + sym.T) / 2)
    sigma = sigma - np.trace(np.linalg.inv(eta) @ sigma) / 3 * h
    anti = rng.normal(size=(4, 4))
    omega = spatial((anti - anti.T) / 2)
    accel = h_mixed.T @ rng.normal(size=4)

    # the pieces must satisfy their defining properties
    assert abs(accel @ u_up) < 1e-10
    assert np.abs(omega + omega.T).max() < 1e-10
    assert np.abs(omega @ u_up).max() < 1e-10
    assert abs(np.trace(np.linalg.inv(eta) @ sigma)) < 1e-10

    Q, theta = 1.3, 0.7
    grad_u = -np.outer(u_dn, accel) + theta / 3 * h + sigma + omega
    antisymmetrised = Q * (grad_u - grad_u.T) / 2

    # the spatial projection of the Q-proportional part is exactly Q omega
    assert np.abs(spatial(antisymmetrised) - Q * omega).max() < 1e-9


def test_averaged_kinetic_stress_is_positive_for_any_correlations():
    """w_eff = 2/3 is an identity, and positivity needs only rho >= 0.

    Section 13.6 first qualified both as holding for superpositions with
    vanishing cross terms. Neither qualification is needed: p = Tr(R)/3 and
    eps_kin = Tr(R)/2 by definition, so their ratio is 2/3 for any field, and
    n.R.n = <rho (n.dv)^2> is non-negative whenever rho is.
    """
    import numpy as np

    rng = np.random.default_rng(0)
    n = 60_000

    def stress(rho, dv):
        return np.einsum("n,ni,nj->ij", rho, dv, dv) / len(rho)

    fields = {
        "independent": rng.normal(size=(n, 3)),
        "rank one": np.outer(rng.normal(size=n), [1.0, 2.0, -0.5]),
        "anticorrelated": (lambda s: np.c_[s, -s, 0.3 * s])(rng.normal(size=n)),
        "heavy tailed": rng.standard_t(1.5, size=(n, 3)),
    }
    for name, dv in fields.items():
        rho = rng.random(n)                       # any non-negative weight
        R = stress(rho, dv)
        assert np.linalg.eigvalsh(R).min() > -1e-10, name
        p = np.trace(R) / 3.0
        eps_kin = 0.5 * np.einsum("n,ni,ni->", rho, dv, dv) / n
        assert abs(p / eps_kin - 2.0 / 3.0) < 1e-12, name

    # a signed weight, which rho >= 0 forbids, does break it
    dv = rng.normal(size=(n, 3))
    R = stress(rng.normal(size=n), dv)
    assert np.linalg.eigvalsh(R).min() < 0.0


def test_the_geodesic_clock_is_forced_not_assumed() -> None:
    """The donor cannot be accelerated, so \\cref{asm:geodesic} is a theorem.

    Checked on a static spherically symmetric metric whose observers *do*
    accelerate, so that the conclusion is a consequence of the hypotheses
    rather than of a degenerate setting: the check asserts the acceleration is
    nonzero before imposing anything, and asserts that an exact vacuum with a
    density gradient does exert a transverse force. Only when the
    no-momentum-transfer hypothesis removes that gradient does the donor's
    equation of motion collapse to ``rho a = 0``.
    """
    assert sy.check_geodesic_forced() is True


def test_a_rolling_canonical_scalar_is_not_an_exact_vacuum() -> None:
    """\\cref{prop:no-rolling}: rho + p = phi_dot^2 for a canonical scalar.

    Built by varying the action on a general diagonal metric rather than by
    quoting the FRW expressions, so that the conclusion does not depend on the
    symmetry it is usually read off from. This is why the vacuum sector of the
    paper is a constrained clock or a four-form and not quintessence.
    """
    assert sy.check_no_rolling() is True
